/*
 * Name: Zhang Lingxin
 * ID:   2100013018
 * 
 * 
 */

#include <stdio.h>
#include <math.h>
#include "csapp.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400
#define OBJECT_NUM 10

struct Uri{
    char hostname[MAXLINE], port[MAXLINE], path[MAXLINE];
};

struct Cache{
    int stamp; // time stamp, intially 0
    int size;
    char uri[MAXLINE];
    char data[MAX_OBJECT_SIZE];
};

struct Cache cache[OBJECT_NUM];

static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";

void doit(int clientfd);
void parse_uri(char *uri, char *hostname, char *port, char *filename, char *requesthdrs);
void send_requesthdrs(rio_t *rp, int serverfd);
void echo(int serverfd, int clientfd, char *uri);
void* thread(void *arg);

/* cache dealing */
void cache_init();
int cache_read(char *uri, int clientfd);
void cache_write(char *buf, char *uri, int size);
int get_max_stamp();

/* reader/writer lock */
sem_t rcmutex, src;
int rcount;

void lock_init();

void serve_static(int fd, char *filename, int filesize);
void get_filetype(char *filename, char *filetype);
void serve_dynamic(int fd, char *filename, char *cgiargs, char *headers);
void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg);

void sigchld_handler(int sig) { // reap all children
    int bkp_errno = errno;
    while(waitpid(-1, NULL, WNOHANG)>0);
    errno=bkp_errno;
}

int main(int argc, char **argv) 
{
    signal(SIGPIPE, SIG_IGN);
    signal(SIGCHLD, sigchld_handler);

    int listenfd;
    int *pconnfd; // for the convenience of argument passing
    char hostname[MAXLINE], port[MAXLINE];
    socklen_t clientlen;
    struct sockaddr_storage clientaddr;
    pthread_t tid;

    /* Check command line args */
    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
        exit(1);
    }

    /* lock init */
    lock_init();
    cache_init();

    listenfd = Open_listenfd(argv[1]);
    while (1) {
        clientlen = sizeof(clientaddr);
        pconnfd = (int*)malloc(sizeof(int));
        *pconnfd = Accept(listenfd, (SA *)&clientaddr, &clientlen); //line:netp:tiny:accept
        Getnameinfo((SA *) &clientaddr, clientlen, hostname, MAXLINE, 
                    port, MAXLINE, 0);
        printf("Accepted connection from (%s, %s)\n", hostname, port);

        pthread_create(&tid, NULL, thread, (void*)pconnfd);
        // doit(connfd);                                             //line:netp:tiny:doit
        // Close(connfd);                                            //line:netp:tiny:close
    }
}

void* thread(void *arg){
    int connfd = *(int*)arg;
    Pthread_detach(pthread_self);
    Free(arg);
    doit(connfd);
    Close(connfd);
    return NULL;
}

/* handle one HTTP request/response transaction */
void doit(int clientfd) 
{
    // fprintf(stderr, "---doit()\n");
    char buf[MAXLINE], method[MAXLINE], uri[MAXLINE], version[MAXLINE];
    char hostname[MAXLINE], port[MAXLINE], path[MAXLINE];
    char requestline[MAXLINE];
    char req_header_buf[MAXLINE], hostheader[MAXLINE];
    rio_t rio;

    /* Read request line and headers */
    Rio_readinitb(&rio, clientfd);
    if (!Rio_readlineb(&rio, buf, MAXLINE))  //line:netp:doit:readrequest
        return;
    sscanf(buf, "%s %s %s", method, uri, version);       //line:netp:doit:parserequest
    fprintf(stderr, "uri=%s\n",uri);
    
    if (strcasecmp(method, "GET")) {                     //line:netp:doit:beginrequesterr
        clienterror(clientfd, method, "501", "Not Implemented",
                    "Proxy does not implement this method");
        return;
    } 
    
                                                       //line:netp:doit:endrequesterr
    // fprintf(stderr, "..begin cache_read..%s\n",uri);
    
    /* parse the uri */
    parse_uri(uri, hostname, port, path, requestline);       //line:netp:doit:staticcheck
   
    /* search cache for the data */
    if(cache_read(uri, clientfd)){
        return;
    }

    // fprintf(stderr, "request line: %s\n",requestline);

    /* open a fd for server */
    int serverfd = Open_clientfd(hostname, port);
    if(serverfd==-1){
        fprintf(stderr, "-- Open_clientfd error:hostname=%s,port=%s\n",hostname,port);
        return;
    }

    /* send request line & request headers to the server */
    Rio_writen(serverfd, requestline, strlen(requestline));
    sprintf(hostheader, "Host: %s\r\n", hostname);
    Rio_writen(serverfd, hostheader, strlen(hostheader));
    send_requesthdrs(&rio, serverfd);

    /* receive lines from server and forward them to client & cache update*/
    echo(serverfd, clientfd, uri);
}

/* parse URI into filename and CGI args */
void parse_uri(char *uri, char *hostname, char *port, char *path, char *requestline) 
{
    char *fir = strstr(uri, "://");
    fir = fir?fir+3:uri;

    /* get hostname */
    char *las = fir;
    while(*las != '/' && *las != ':') las++;
    strncpy(hostname, fir, las-fir);
    // fprintf(stderr, "hostname: %s\n",hostname);

    /* get port */
    if(*las==':'){
    /* if uri includes path */
        fir = las+1;
        las = strstr(las, "/");
        strncpy(port, fir, las-fir);
    }
    else sprintf(port, "80"); // default port
    
    // fprintf(stderr, "port: %s\n",port);

    /* get path */
    fir = las;
    las = uri + strlen(uri);
    strncpy(path, fir, las-fir);
    // fprintf(stderr, "path: %s\n",path);

    /* request line generation */
    sprintf(requestline, "GET %s HTTP/1.0\r\n", path);
}

/* send other request headers */
void send_requesthdrs(rio_t *rp, int serverfd){
    char header[MAXLINE];

    /* send given user_agent_hdr, connection header and proxy-connection header */
    Rio_writen(serverfd, user_agent_hdr, strlen(user_agent_hdr));
    sprintf(header, "Connection: close\r\n");
    Rio_writen(serverfd, header, strlen(header));
    sprintf(header, "Proxy-Connection: close\r\n");
    Rio_writen(serverfd, header, strlen(header));

    /* send other headers as they are */
    while(1){
        Rio_readlineb(rp, header, MAXLINE);
        if(!strcmp(header, "\r\n")) break;
        if(!strncmp("Host", header, 4) || !strncmp("User-Agent", header, 10) ||
                !strncmp("Connection", header, 4) || !strncmp("Proxy-Connection", header, 16))
            continue;
        fprintf(stderr, "%s",header);
        Rio_writen(serverfd, header, strlen(header));
    }
    Rio_writen(serverfd, header, strlen(header));
}

/* receive lines from server and forward them to client & cache update*/
void echo(int serverfd, int clientfd, char *uri){
    size_t n, size=0;
    char buf[MAXLINE], *data;
    rio_t rio;

    data = Malloc(MAX_OBJECT_SIZE);
    /* receive lines from server and forward them to client */
    Rio_readinitb(&rio, serverfd);
    while((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0){
        if(size+n < MAX_OBJECT_SIZE){
            memcpy(data+size, buf, n);
            size +=n;
        }
        else size = MAX_OBJECT_SIZE + 1;
        Rio_writen(clientfd, buf, n);
    }   

    /* cache update */
    if(size < MAX_OBJECT_SIZE)
        cache_write(data, uri, size);
    free(data);
}


void get_filetype(char *filename, char *filetype) 
{
    if (strstr(filename, ".html"))
        strcpy(filetype, "text/html");
    else if (strstr(filename, ".gif"))
        strcpy(filetype, "image/gif");
    else if (strstr(filename, ".png"))
        strcpy(filetype, "image/png");
    else if (strstr(filename, ".jpg"))
        strcpy(filetype, "image/jpeg");
    else if (strstr(filename, ".css"))
        strcpy(filetype, "text/css");
    else if (strstr(filename, ".js"))
        strcpy(filetype, "application/javascript");
    else
        strcpy(filetype, "text/plain");
}  
/* $end serve_static */

/* client error: returns an error message to the client */
void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg) 
{
    char buf[MAXLINE], body[MAXBUF];

#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wformat-overflow"
    /* Build the HTTP response body */
    sprintf(body, "<html><title>Tiny Error</title>");
    sprintf(body, "%s<body bgcolor=""ffffff"">\r\n", body);
    sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
    sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
    sprintf(body, "%s<hr><em>The Tiny Web server</em>\r\n", body);
#pragma GCC diagnostic pop

    /* Print the HTTP response */
    sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
    Rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-type: text/html\r\n");
    Rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-length: %d\r\n\r\n", (int)strlen(body));
    Rio_writen(fd, buf, strlen(buf));
    Rio_writen(fd, body, strlen(body));
}

void lock_init(){
    rcount = 0;
    sem_init(&rcmutex, 0, 1);
    sem_init(&src, 0, 1);
}

int cache_read(char *uri, int clientfd){

    /* lock */
    sem_wait(&rcmutex);
    rcount++;
    if(rcount == 1){
        sem_wait(&src);
    }
    sem_post(&rcmutex);

    /* reading.. */
    int idx = -1;
    for(int i=0;i<OBJECT_NUM;i++){
        if(cache[i].stamp!=0 && strcmp(uri, cache[i].uri)==0){
            idx = i;
            cache[i].stamp = get_max_stamp() + 1;
            break;
        }
    }

    if(idx==-1) {
        // fprintf(stderr, "---cache_read():miss\n");
        sem_wait(&rcmutex);
        rcount--;
        if(rcount == 0){
            sem_post(&src);
        }
        sem_post(&rcmutex);
        
        return 0;
    }

    // fprintf(stderr, "---cache_read():hit\n");
    Rio_writen(clientfd, cache[idx].data, cache[idx].size);

    /* unlock */
    sem_wait(&rcmutex);
    rcount--;
    if(rcount == 0){
        sem_post(&src);
    }
    sem_post(&rcmutex);

    // /* stamp update(writing..) */
    // sem_wait(&src);
    // cache[idx].stamp = get_max_stamp() + 1;
    // sem_post(&src);

    return 1;
}

void cache_write(char *data, char *uri, int size){
    // fprintf(stderr, "---cache_write():uri=%s,size=%d\n",uri, size);
    sem_wait(&src);

    /* writing.. */
    int idx=0, minstamp = cache[0].stamp, maxstamp=0;
    for(int i=1;i<OBJECT_NUM;i++){
        if(size>0 && cache[i].stamp < minstamp){
            idx = i;
            minstamp = cache[i].stamp;
        }
        if(maxstamp < cache[i].stamp)
            maxstamp = cache[i].stamp;
    }

    memcpy(cache[idx].uri, uri, strlen(uri));
    memcpy(cache[idx].data, data, size);
    cache[idx].stamp = maxstamp + 1;
    cache[idx].size = size;

    sem_post(&src);

    // fprintf(stderr, "---cache_write():finished");

}

int get_max_stamp(){
    int maxstamp=0;
    for(int i=1;i<OBJECT_NUM;i++){
        if(maxstamp < cache[i].stamp)
            maxstamp = cache[i].stamp;
    }
    return maxstamp;
}

void cache_init(){
    for(int i=0;i<OBJECT_NUM;i++){
        cache[i].size = cache[i].stamp = 0;
        memset(cache[i].data,0,sizeof(cache[i].data));
        memset(cache[i].uri,0,sizeof(cache[i].uri));
    }
}
